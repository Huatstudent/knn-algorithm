import statistics
sample = [1,2,3,3,3,4,5,5]
max(set(sample), key=sample.count)
print(max(set(sample), key=sample.count))