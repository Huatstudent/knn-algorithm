import os
import numpy as np
import cv2
# Ctrl + alt + m:代码已经写好，提取成一个方法
# 占位符
# Python 语言中，def 定义方法
def data_process(file):
    dirs = os.listdir('./faces/%d'%(file))
    d = [int(d.split('.')[0]) for d in dirs]
    nd = np.array(d)
    # nd2文件名大于100，改名
    cond = nd > 100  # 逻辑运算，True，False
    nd2 = nd[cond]
    # nd1 当前文件夹下已经存在的文件
    cond = nd <= 100
    nd1 = nd[cond]
    print('+++++++++++++++++++++++++++++', nd2)
    print(nd1)
    nd3 = np.arange(1, 101)
    # print(nd3)#nd3 1 ~ 100 全面
    # 缺失的1~100文件名，文件要改名，只能用这些名字
    nd4 = list(set(nd3).difference(set(nd1)))
    print('--------------------------', nd4)
    for i, fn in enumerate(nd2):
        # IndexError: list index out of range  nd4空
        try:
            os.rename('./faces/%d/%d.jpg' % (file,fn), './faces/%d/%d.jpg'%(file,nd4[i]))
        except:
            os.remove('./faces/%d/%d.jpg' % (file,fn))
    for i in nd4:
        index = np.random.choice(nd1, size=1)[0]
        img = cv2.imread('./faces/%d/%d.jpg' % (file,index))
        cv2.imwrite('./faces/%d/%d.jpg' % (file,i), img)
    for i in nd3:
        img = cv2.imread('./faces/%d/%d.jpg' % (file,i))
        result = cv2.resize(img, (64, 64))
        cv2.imwrite('./faces/%d/%d.jpg' % (file,i), result)

for i in range(8):
    data_process(i)