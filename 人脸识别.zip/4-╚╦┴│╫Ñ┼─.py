import cv2
import os
if __name__ == '__main__':
    v = cv2.VideoCapture(0) # 参数是0，读取本机的摄像头，允许其他程序访问
    face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_alt.xml')#Ctrl + Alt + V
    num = 1
    name = input('请输入拍照的名字：')
    while True:
        flag,frame = v.read()
        if flag == False:
            break #退出
        gray = cv2.cvtColor(frame, code=cv2.COLOR_BGR2GRAY)#黑白图片，尺寸和原来彩色一模一样
        faces = face_detector.detectMultiScale(gray,scaleFactor=1.2,minNeighbors=3)
        for x,y,w,h in faces:
            face = frame[y:y+h,x:x+w]
            print('----------已采集%d张----------'%(num))
            try:
                os.makedirs('./faces/%s'%(name),exist_ok=False)
            except:
                pass
            cv2.imwrite('./faces/%s/%d.jpg'%(name,num),face)

            num+=1
            cv2.rectangle(frame,pt1=(x,y),pt2=(x+w,y+h),color=[0,0,255],thickness=2)#蓝绿红（0 ~ 255）
        if num == 101:
            print('----------采集完毕----------')
            name = input('请输入另一个的名字：（输入N退出）')
            num = 1
            if name == 'N':
                break
        cv2.imshow('shexiangtou',frame)
        if ord('q') == cv2.waitKey(41):
            break
    v.release()
    cv2.destroyAllWindows()