import numpy as np
import cv2
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split


def load_data():
    #TODO 加载数据
    X = []
    for i in range(28):
        for j in range(1,101):
            face = cv2.imread('./faces/%d/%d.jpg'%(i,j)) #三维
            g_face = cv2.cvtColor(face,code = cv2.COLOR_BGR2GRAY) #黑白 二维
            X.append(g_face) #X添加了二维图片，X三维数据
    y = [i for i in range(28)]*100
    y = sorted(y) #排序
    X,y = np.array(X),np.array(y) #数据类型转变，numpy,功能方法多，操作方便
    X = X.reshape(2800,4096) #二维，算法可以训练
    return train_test_split(X,y,test_size=0.1)

if __name__ == '__main__':
    #第一步，加载数据
    X_train,X_test,y_train,y_test = load_data() #万能建Alt+Enter

    #第二步，标签
    labels = []

    #第三步，算法
    knn = KNeighborsClassifier(5)

    #第四步，训练
    knn.fit(X_train,y_train)

    #第五步，预测
    y_ = knn.predict(X_test)

    #第六步，算法的准确率
    print('算法人脸识别准确率是：',(y_test == y_).mean())
    print('真实人脸类别是：',y_test)
    print('预测人脸类别是：',y_)

    #第七步，可视化
    for i in range(280):
        cv2.namedWindow('who',flags=cv2.WINDOW_NORMAL)
        cv2.resize('who',128,128)
        cv2.imshow('who',X_test[i].reshape(64,64))
        print('这张人脸是：',labels[y_test[i]])
        print('这张人脸算法预测的是：',labels[y_[i]])
        if ord('q') == cv2.waitKey(0):
            break
        cv2.destroyAllWindows()