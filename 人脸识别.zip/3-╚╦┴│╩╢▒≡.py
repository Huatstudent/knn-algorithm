import numpy as np
import cv2
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split


def load_data():
    #加载数据
    X = []
    for i in range(8):
        for j in range(1,101):
            face = cv2.imread('./faces/%d/%d.jpg'%(i,j))#三维
            g_face = cv2.cvtColor(face,code = cv2.COLOR_BGR2GRAY)#黑白二维
            X.append(g_face)#X添加了二维图片，X三维数据
    y = [i for i in range(8)]*100
    y = sorted(y)
    X ,y = np.array(X),np.array(y)#数据类型转变，numpy，功能方法多，操作方便
    X = X.reshape(800,4096)#二维，算法可以训练
    return X,y

def camera_data():
    v = cv2.VideoCapture(0)  # 参数0，读取本机的摄像头允许其他程序访问
    face_detector = cv2.CascadeClassifier('./haarcascade_frontalface_alt.xml')
    z = []
    num = 1
    while True:
        flag, frame = v.read()  # 读视频下一帧到frame，当读取不到内容时返回false给flag
        if flag == False:
            break
        gray = cv2.cvtColor(frame, code=cv2.COLOR_BGR2GRAY)  # 黑白图片，尺寸和原来彩色一模一样
        faces = face_detector.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)
        for x, y, w, h in faces:
            face = frame[y:y + h, x:x + w]  # 高度和宽度
            num += 1
            result = cv2.resize(face, (64,64))
            g_face = cv2.cvtColor(result, code=cv2.COLOR_BGR2GRAY)  # 黑白二维
            z.append(g_face)
        if num == 21:
            break
        cv2.imshow('shexiangtou', frame)
        if ord('q') == cv2.waitKey(41):
            break
    v.release()
    cv2.destroyAllWindows()
    z = np.array(z)
    z = z.reshape(20, 4096)  # 二维，算法可以训练
    return z


if __name__ == '__main__':
    # 第一步，加载数据
    while True:
        name = input('请输入进行识别人的名字：（输入N退出）')
        if name == 'N':
            break
        X_train,y_train= load_data()  # 万能建Alt+Enter
        X_test = camera_data()
        # 第二步，标签
        labels = ['刘爽', '王波', '母潮峰',
                  '王泽众', '方俊伟', '程实 ','李飞', '叶倩倩']

        # 第三步，算法
        knn = KNeighborsClassifier(5)

        # 第四步，训练
        knn.fit(X_train, y_train)

        # 第五步，预测,弱分类器，光线，距离，影响比较大，卷积运算
        y_ = knn.predict(X_test)
        print('-----------',y_)

        # 第七步，可视化
        print('算法预测的人脸是：', labels[max(set(y_), key=y_.tolist().count)])
        print('真实的人脸是：',name)

    cv2.destroyAllWindows()